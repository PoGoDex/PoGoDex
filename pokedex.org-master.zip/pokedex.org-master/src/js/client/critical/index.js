require('./asyncSpritesCss');
require('../shared/worker');