var pageSize = require('../shared/util/constants').pageSize;

module.exports = {
  filter: '',
  start: 0,
  end: pageSize
};