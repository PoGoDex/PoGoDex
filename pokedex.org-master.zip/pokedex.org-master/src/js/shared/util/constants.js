module.exports = {
  pageSize: 3000000,
  numSpriteCssFiles: 10,
  initialWindowSize: 100
};